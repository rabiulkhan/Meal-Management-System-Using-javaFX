/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mealmanagementsystem.ui.dashboard;

import com.jfoenix.effects.JFXDepthManager;
import java.io.IOException;
import java.net.URL;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Optional;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonType;
import javafx.scene.control.Label;
import javafx.scene.input.MouseDragEvent;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;
import javafx.stage.StageStyle;
import mealmanagementsystem.database.DatabaseHandler;

/**
 * FXML Controller class
 *
 * @author md.rabiulkhan
 */
public class DashboardController implements Initializable {

    @FXML
    private AnchorPane totalMemberPanel;
    @FXML
    private Label totalMember;
    @FXML
    private AnchorPane totalMealPanel;
    @FXML
    private Label totalMeal;
    @FXML
    private AnchorPane totalBazarPanel;
    @FXML
    private Label totalBazar;
    @FXML
    private AnchorPane mealRatePanel;
    @FXML
    private Label mealRate;

    DatabaseHandler databaseHandler;
    @FXML
    private Button addMembers;
    @FXML
    private Button refreshBtn;
    @FXML
    private AnchorPane rootPane;
    @FXML
    private Button addMealBtn;
    @FXML
    private Button addBazarBtn;
    @FXML
    private Button membersContribBtn;
    @FXML
    private Button monthClosingBtn;
    @FXML
    private Button logoutBtn;

    String lastDay = "", firstDay = "";
    float totalMealc = 0;
    @FXML
    private Button deleteBtn;

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        databaseHandler = new DatabaseHandler();
        totalMember.setText(totalMember());
        DateTimeFormatter dtf = DateTimeFormatter.ofPattern("dd-MM-yyyy");
        LocalDate today = LocalDate.now();

        LocalDate first = today.withDayOfMonth(1);
        firstDay = dtf.format(first).toString();
        LocalDate last = today.withDayOfMonth(today.lengthOfMonth());
        lastDay = dtf.format(last).toString();

        totalMealCalculate();
        totalBazarCalculate();
    }

    private void addMemberAction(MouseDragEvent event) throws IOException {

    }

    public String totalMember() {
        String total = "";
        try {

            String query = "select count(userName) as userName from USERS";
            ResultSet rs = databaseHandler.execQuery(query);

            while (rs.next()) {
                total = rs.getString("userName");
            }

        } catch (SQLException ex) {
            Logger.getLogger(DashboardController.class.getName()).log(Level.SEVERE, null, ex);
        }
        return total;
    }

    void totalMealCalculate() {
        try {

            String sql = "select Sum(cast(breakfast as DECIMAL(9,2))) as breakfast,Sum(cast(lunch as DECIMAL(9,2))) as lunch,Sum(cast(dinner as DECIMAL(9,2))) as dinner from MEAL  where date >= '" + firstDay + "' and date <= '" + lastDay + "'";

            ResultSet rs = databaseHandler.execQuery(sql);
            while (rs.next()) {
                String bfs = rs.getString("breakfast");
                if(bfs == null){
                    bfs = "0";
                }
                String lnch = rs.getString("lunch");
                if(lnch == null){
                    lnch = "0";
                }
                String dnr = rs.getString("dinner");
                if(dnr == null){
                    dnr = "0";
                }

                totalMealc = Float.parseFloat(bfs) + Float.parseFloat(lnch) + Float.parseFloat(dnr);
            }

            totalMeal.setText(String.valueOf(totalMealc));
        } catch (SQLException ex) {
            Logger.getLogger(DashboardController.class.getName()).log(Level.SEVERE, null, ex);
        }

    }

    void totalBazarCalculate() {

        try {
            float totalBazarc = 0;
            String sql = "select Sum(cast(cost as DECIMAL(9,2))) as cost from BAZAR  where date >= '" + firstDay + "' and date <= '" + lastDay + "'";

            ResultSet rs = databaseHandler.execQuery(sql);
            while (rs.next()) {
                String cst = rs.getString("cost");
                
                if(cst == null){
                    cst = "0";
                }

                totalBazarc = Float.parseFloat(cst);
            }

            totalBazar.setText(String.valueOf(totalBazarc));
            mealRate.setText(String.valueOf(totalBazarc / totalMealc));
        } catch (SQLException ex) {
            Logger.getLogger(DashboardController.class.getName()).log(Level.SEVERE, null, ex);
        }

    }

    void loadWindow(String loc, String title) throws IOException {

        Parent parent = FXMLLoader.load(getClass().getResource(loc));
        Stage stage = new Stage(StageStyle.DECORATED);
        stage.setTitle(title);
        stage.setScene(new Scene(parent));
        stage.show();

    }

    @FXML
    private void addMemberActions(ActionEvent event) throws IOException {
        loadWindow("/mealmanagementsystem/ui/signup/signup.fxml", "Add New Member");
    }

    @FXML
    private void refreshAction(ActionEvent event) {
        totalMember.setText(totalMember());
        
        totalBazarCalculate();
        totalMealCalculate();
    }

    @FXML
    private void addMealActions(ActionEvent event) throws IOException {
        loadWindow("/mealmanagementsystem/ui/add_meal/add_meal.fxml", "Add meal");
    }

    @FXML
    private void addBazarActions(ActionEvent event) throws IOException {
        loadWindow("/mealmanagementsystem/ui/bazar/add_bazar.fxml", "Add Daily Cost");
    }

    @FXML
    private void mambersContribAction(ActionEvent event) throws IOException {
        loadWindow("/mealmanagementsystem/ui/contribution/contribution.fxml", "Add Member Contributions");
    }

    @FXML
    private void monthClosingActions(ActionEvent event) throws IOException {
        loadWindow("/mealmanagementsystem/ui/closing/closing.fxml", "Month Closing");
    }

    @FXML
    private void logOutActions(ActionEvent event) throws IOException {
        Stage stage = (Stage) rootPane.getScene().getWindow();
        stage.close();
        loadWindow("/mealmanagementsystem/ui/login/login.fxml", "Login");
    }

    private void deleteBtnAction(ActionEvent event) throws IOException {
        String sql1 = "TRUNCATE TABLE USERS";
        String sql2 = "TRUNCATE TABLE MEAL";
        String sql3 = "TRUNCATE TABLE BAZAR";
        String sql4 = "TRUNCATE TABLE CONTRIBUTION";

        Alert alert = new Alert(AlertType.CONFIRMATION);
        alert.setTitle("Delete File");
        alert.setHeaderText("");
        alert.setContentText("Are you sure want to Delete all record?");
        Optional<ButtonType> option = alert.showAndWait();
        if (option.get() == null) {

        } else if (option.get() == ButtonType.OK) {
            String msg = databaseHandler.delete(sql1, sql2, sql3, sql4);
            if (msg.equals("yes")) {
                Alert alert1 = new Alert(AlertType.INFORMATION);
                alert1.setTitle("");
                alert1.setHeaderText("");
                alert1.setContentText("Deleted");
                
                Stage stage = (Stage) rootPane.getScene().getWindow();
                stage.close();
                loadWindow("/mealmanagementsystem/ui/login/login.fxml", "Login");
            } else {
                Alert alert1 = new Alert(AlertType.INFORMATION);
                alert1.setTitle("");
                alert1.setHeaderText("");
                alert1.setContentText("Failed to Delete");
            }
        } else if (option.get() == ButtonType.CANCEL) {

        } else {

        }
    }

    @FXML
    private void deleteBtnActions(ActionEvent event) {
        
    }

}
