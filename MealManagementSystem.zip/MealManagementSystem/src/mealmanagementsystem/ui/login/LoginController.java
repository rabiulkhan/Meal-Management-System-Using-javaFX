/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mealmanagementsystem.ui.login;

import com.jfoenix.effects.JFXDepthManager;
import java.io.IOException;
import java.net.URL;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.Hyperlink;
import javafx.scene.control.TextField;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseDragEvent;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;
import javafx.stage.StageStyle;
import mealmanagementsystem.database.DatabaseHandler;

/**
 * FXML Controller class
 *
 * @author md.rabiulkhan
 */
public class LoginController implements Initializable {

    @FXML
    private VBox userPane;
    @FXML
    private TextField userName;
    @FXML
    private TextField password;
    @FXML
    private ImageView showPass;
    @FXML
    private Button signupBtn;
    @FXML
    private Button loginBtn;
    @FXML
    private Hyperlink forgotPass;

    DatabaseHandler databaseHandler;
    @FXML
    private AnchorPane rootPane;

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        JFXDepthManager.setDepth(userPane, 2);

        databaseHandler = new DatabaseHandler();
    }

    @FXML
    private void showPassAction(MouseDragEvent event) {
        String pass = password.getText();
        password.setText(pass);
    }

    @FXML
    private void signUpAction(ActionEvent event) {

        loadWindow("/mealmanagementsystem/ui/signup/signup.fxml", "Registration Window");
    }

    @FXML
    private void loginAction(ActionEvent event) {

        try {
            String username = userName.getText();
            String pass = password.getText();

            String query = "select count(userName) as userName from USERS where userName = '" + username + "' and password = '" + pass + "'";
            String isUser = "";
            ResultSet rs = databaseHandler.execQuery(query);
            while (rs.next()) {
                
                isUser = rs.getString("userName");
            }

            if (isUser.equals("1")) {
                Stage stage = (Stage) rootPane.getScene().getWindow();
                stage.close();
                loadWindow("/mealmanagementsystem/ui/dashboard/dashboard.fxml", "Dashboard");

            } else {
                Alert alert = new Alert(Alert.AlertType.ERROR);
                alert.setHeaderText("");
                alert.setContentText("wrong User name or password");
                alert.showAndWait();
                return;
            }
        } catch (SQLException ex) {
            Logger.getLogger(LoginController.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    @FXML
    private void forgotPassAction(ActionEvent event) {

        loadWindow("/mealmanagementsystem/ui/forgot_password/forgot_password.fxml", "Forgot Password Window");
    }

    void loadWindow(String loc, String title) {
        try {
            Parent parent = FXMLLoader.load(getClass().getResource(loc));
            Stage stage = new Stage(StageStyle.DECORATED);
            stage.setTitle(title);
            stage.setScene(new Scene(parent));
            stage.show();
        } catch (IOException ex) {
            Logger.getLogger(LoginController.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

}
