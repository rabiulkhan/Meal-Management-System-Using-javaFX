/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mealmanagementsystem.ui.closing;

import java.io.IOException;
import java.net.URL;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.beans.property.SimpleStringProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.DatePicker;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.Pane;
import javafx.scene.text.Text;
import javafx.stage.Stage;
import javafx.stage.StageStyle;
import mealmanagementsystem.database.DatabaseHandler;
import mealmanagementsystem.ui.details.DetailsController;

/**
 * FXML Controller class
 *
 * @author md.rabiulkhan
 */
public class ClosingController implements Initializable {

    @FXML
    private DatePicker startDate;
    @FXML
    private DatePicker endDate;
    @FXML
    private Button calculateBtn;
    @FXML
    private Text durationMsg;
    @FXML
    private Text totalMealMsg;
    @FXML
    private Text totalBazarMsg;
    @FXML
    private Text mealRateMsg;
    @FXML
    private TableView<Table> tableView;
    @FXML
    private TableColumn<Table, String> userCol;
    @FXML
    private TableColumn<Table, String> mealCol;
    @FXML
    private TableColumn<Table, String> givenCol;
    @FXML
    private TableColumn<Table, String> remarkCol;

    DatabaseHandler databaseHandler;

    ObservableList memberList = FXCollections.observableArrayList();
    ObservableList<Table> dataList = FXCollections.observableArrayList();

    float totalMeal = 0;
    float totalBazar = 0;
    String user="",ssDate = "",seDate = "";

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        databaseHandler = new DatabaseHandler();
    }

    @FXML
    private void calculateBtnAction(ActionEvent event) throws SQLException {
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd-MM-yyyy");
        LocalDate date = startDate.getValue();
        LocalDate date1 = endDate.getValue();
        String selectedStartDate = formatter.format(date);
        String selectedEndDate = formatter.format(date1);
        
        ssDate = selectedStartDate;
        seDate = selectedEndDate;

        durationMsg.setText("Calculation Between " + selectedStartDate + " to " + selectedEndDate);

        totalMealCalculate(selectedStartDate, selectedEndDate);
        totalBazarCalculate(selectedStartDate, selectedEndDate);

        mealRateMsg.setText("Meal Rate = " + (totalBazar / totalMeal));
        initCol();
        loadMember();
        loadData(selectedStartDate, selectedEndDate);
    }

    @FXML
    private void tableClickAction(MouseEvent event) throws IOException {

        Table tableData = tableView.getSelectionModel().getSelectedItem();
        
        user = tableData.getUserName();
    
        
        Stage primaryStage = new Stage();
        FXMLLoader loader = new FXMLLoader();
        loader.setLocation(getClass().getResource("/mealmanagementsystem/ui/details/details.fxml"));
        try{
            loader.load();
        }catch(IOException ex){
            System.out.println("exception : "+ex);
        }
        DetailsController detailsController = (DetailsController) loader.getController();
        detailsController.getValue(user, ssDate, seDate);
        
        Parent p = loader.getRoot();
        Stage stage = new Stage();
        stage.setScene(new Scene(p));
        stage.showAndWait();

    }

    void totalMealCalculate(String startDate, String endDate) {
        try {

            String sql = "select Sum(cast(breakfast as DECIMAL(9,2))) as breakfast,Sum(cast(lunch as DECIMAL(9,2))) as lunch,Sum(cast(dinner as DECIMAL(9,2))) as dinner from MEAL  where date >= '" + startDate + "' and date <= '" + endDate + "'";

            ResultSet rs = databaseHandler.execQuery(sql);
            while (rs.next()) {
                String bfs = rs.getString("breakfast");
                String lnch = rs.getString("lunch");
                String dnr = rs.getString("dinner");

                totalMeal = Float.parseFloat(bfs) + Float.parseFloat(lnch) + Float.parseFloat(dnr);
            }

            totalMealMsg.setText("Total Meal = " + totalMeal);
        } catch (SQLException ex) {
            Logger.getLogger(ClosingController.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    void totalBazarCalculate(String startDate, String endDate) {
        try {

            String sql = "select Sum(cast(cost as DECIMAL(9,2))) as cost from BAZAR  where date >= '" + startDate + "' and date <= '" + endDate + "'";

            ResultSet rs = databaseHandler.execQuery(sql);
            while (rs.next()) {
                String cst = rs.getString("cost");

                totalBazar = Float.parseFloat(cst);
            }

            totalBazarMsg.setText("Total Bazar = " + totalBazar);
        } catch (SQLException ex) {
            Logger.getLogger(ClosingController.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    void loadMember() {
        try {
            String query = "select userName from USERS";

            ResultSet rs = databaseHandler.execQuery(query);

            while (rs.next()) {
                memberList.add(rs.getString("userName"));
            }
        } catch (SQLException ex) {
            Logger.getLogger(ClosingController.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    void loadData(String startDate, String endDate) throws SQLException {
        String meal = "";
        String given = "";
        String remark = "";
        String member = "";
        float givens = 0, meals = 0;
        
        for (int i = 0; i < memberList.size(); i++) {
            
            member = memberList.get(i).toString();

            String sql = "select Sum(cast(breakfast as DECIMAL(9,2))) as breakfast,Sum(cast(lunch as DECIMAL(9,2))) as lunch,Sum(cast(dinner as DECIMAL(9,2))) as dinner from MEAL  where userName = '" + member + "' and date >= '" + startDate + "' and date <= '" + endDate + "'";

            ResultSet rs = databaseHandler.execQuery(sql);
            while (rs.next()) {
                String bfs = rs.getString("breakfast");
                if(bfs == null){
                    bfs = "0.0";
                }
                String lnch = rs.getString("lunch");
                if(lnch == null){
                    lnch = "0.0";
                }
                String dnr = rs.getString("dinner");
                if(dnr == null){
                    dnr = "0.0";
                }

                meals = Float.parseFloat(bfs) + Float.parseFloat(lnch) + Float.parseFloat(dnr);
                meal = String.valueOf(meals);
            }

            String sql1 = "select Sum(cast(amount as DECIMAL(9,2))) as amount from CONTRIBUTION where userName = '" + member + "' and date >= '" + startDate + "' and date <= '" + endDate + "'";

            ResultSet rs1 = databaseHandler.execQuery(sql1);
            while (rs1.next()) {

                String amount = rs1.getString("amount");
                if(amount == null){
                    amount = "0.0";
                }
                givens = Float.parseFloat(amount);
                given = String.valueOf(givens);
            }

            float cost = givens - (meals * (totalBazar / totalMeal));
            if (cost >= 0) {
                remark = "have to pay to member " + cost;
            } else {
                remark = "should pay to Manager " + cost;
            }
            
            dataList.add(new Table(member, meal, given, remark));

        }
        tableView.getItems().setAll(dataList);
    }

    void initCol() {
        userCol.setCellValueFactory(new PropertyValueFactory<>("userName"));
        mealCol.setCellValueFactory(new PropertyValueFactory<>("totalMeal"));
        givenCol.setCellValueFactory(new PropertyValueFactory<>("totalGiven"));
        remarkCol.setCellValueFactory(new PropertyValueFactory<>("remark"));
    }

    public static class Table {

        private final SimpleStringProperty userName;
        private final SimpleStringProperty totalMeal;
        private final SimpleStringProperty totalGiven;
        private final SimpleStringProperty remark;

        public Table(String userName, String totalMeal, String totalGiven, String remark) {
            this.userName = new SimpleStringProperty(userName);
            this.totalMeal = new SimpleStringProperty(totalMeal);
            this.totalGiven = new SimpleStringProperty(totalGiven);
            this.remark = new SimpleStringProperty(remark);
        }

        public String getUserName() {
            return userName.get();
        }

        public String getTotalMeal() {
            return totalMeal.get();
        }

        public String getTotalGiven() {
            return totalGiven.get();
        }

        public String getRemark() {
            return remark.get();
        }

    }

}
