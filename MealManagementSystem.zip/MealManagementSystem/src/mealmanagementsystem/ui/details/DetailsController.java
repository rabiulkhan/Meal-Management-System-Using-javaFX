/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mealmanagementsystem.ui.details;

import java.net.URL;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.beans.property.SimpleStringProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.text.Text;
import mealmanagementsystem.database.DatabaseHandler;

/**
 * FXML Controller class
 *
 * @author md.rabiulkhan
 */
public class DetailsController implements Initializable {

    @FXML
    private Text userNameMsg;
    @FXML
    private Text durationMsg;
    @FXML
    private TableColumn<Table, String> dateCol;
    @FXML
    private TableColumn<Table, String> breakfastCol;
    @FXML
    private TableColumn<Table, String> lunchCol;
    @FXML
    private TableColumn<Table, String> DinnerCol;
    @FXML
    private TableColumn<Table, String> bazarCol;

    String user = "", startDatex = "", endDatex = "";
    @FXML
    private TableView<Table> tableView;

    DatabaseHandler databaseHandler;
    ObservableList<Table> dataList = FXCollections.observableArrayList();

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        databaseHandler = new DatabaseHandler();

    }

    public void getValue(String userName, String startDate, String endDate) {
        user = userName;
        startDatex = startDate;
        endDatex = endDate;

        userNameMsg.setText(user);
        durationMsg.setText("Details from " + startDatex + " to " + endDatex);

        initCol();
        loadData();
    }

    void initCol() {
        dateCol.setCellValueFactory(new PropertyValueFactory<>("date"));
        breakfastCol.setCellValueFactory(new PropertyValueFactory<>("breakfast"));
        lunchCol.setCellValueFactory(new PropertyValueFactory<>("lunch"));
        DinnerCol.setCellValueFactory(new PropertyValueFactory<>("dinner"));
    }

    void loadData() {
        try {
            String date = "", bf = "", ln = "", dnr = "", bzr = "";

            String splitStart[], splitEnd[], eMonth = "", eYear = "";
            int sday = 0, sMonth = 0, sYear = 0, eday = 0;
            splitStart = startDatex.split("-");
            sday = Integer.parseInt(splitStart[0]);
            sMonth = Integer.parseInt(splitStart[1]);
            sYear = Integer.parseInt(splitStart[2]);

            splitEnd = endDatex.split("-");
            eday = Integer.parseInt(splitEnd[0]);
            eMonth = splitEnd[1];
            eYear = splitEnd[2];

            for (int i = sday; i <= eday; i++) {
                String d = String.valueOf(i);
                if (d.length() == 1) {
                    d = "0" + d;
                }
                String bDate = d + "-" + eMonth + "-" + eYear;
                String sql = "select * from MEAL  where userName = '" + user + "' and date = '" + bDate + "' order by date asc";
                System.out.println(sql);
                ResultSet rs = databaseHandler.execQuery(sql);
                while (rs.next()) {
                    date = rs.getString("date");
                    bf = rs.getString("breakfast");
                    if (bf == null) {
                        bf = "0.0";
                    }
                    ln = rs.getString("lunch");
                    if (ln == null) {
                        ln = "0.0";
                    }
                    dnr = rs.getString("dinner");
                    if (dnr == null) {
                        dnr = "0.0";
                    }

                    String sql1 = "select cost from BAZAR  where date = '" + bDate + "'";

                    ResultSet rs1 = databaseHandler.execQuery(sql1);
                    while (rs1.next()) {
                        bzr = rs1.getString("cost");
                        if (bzr == null) {
                            bzr = "0";
                        }

                    }

                    dataList.add(new Table(date, bf, ln, dnr));

                }

            }

            tableView.getItems().setAll(dataList);
        } catch (SQLException ex) {
            Logger.getLogger(DetailsController.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    public static class Table {

        private final SimpleStringProperty date;
        private final SimpleStringProperty breakfast;
        private final SimpleStringProperty lunch;
        private final SimpleStringProperty dinner;

        Table(String date, String breakfast, String lunch, String dinner) {
            this.date = new SimpleStringProperty(date);
            this.breakfast = new SimpleStringProperty(breakfast);
            this.lunch = new SimpleStringProperty(lunch);
            this.dinner = new SimpleStringProperty(dinner);
        }

        public String getDate() {
            return date.get();
        }

        public String getBreakfast() {
            return breakfast.get();
        }

        public String getLunch() {
            return lunch.get();
        }

        public String getDinner() {
            return dinner.get();
        }


    }

}
