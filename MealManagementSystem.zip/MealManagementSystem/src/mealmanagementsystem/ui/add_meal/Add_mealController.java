/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mealmanagementsystem.ui.add_meal;

import com.jfoenix.effects.JFXDepthManager;
import java.net.URL;
import java.sql.Date;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.beans.property.SimpleStringProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.DatePicker;
import javafx.scene.control.SingleSelectionModel;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.input.MouseDragEvent;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.AnchorPane;
import mealmanagementsystem.database.DatabaseHandler;

/**
 * FXML Controller class
 *
 * @author md.rabiulkhan
 */
public class Add_mealController implements Initializable {

    ObservableList memberList = FXCollections.observableArrayList();
    ObservableList<MealList> mealList = FXCollections.observableArrayList();
    
    ObservableList selectedMemberList = FXCollections.observableArrayList();

    DatabaseHandler databaseHandler;
    @FXML
    private DatePicker datePicker;
    @FXML
    private ComboBox<?> memberCombo;
    @FXML
    private TextField breakfast;
    @FXML
    private TextField lunch;
    @FXML
    private TextField dinner;
    @FXML
    private Button updateBtn;
    @FXML
    private Button saveBtn;
    @FXML
    private AnchorPane rootPane;
    @FXML
    private TableView<MealList> tableView;
    @FXML
    private TableColumn<MealList, String> dateCol;
    @FXML
    private TableColumn<MealList, String> userCol;
    @FXML
    private TableColumn<MealList, String> bfCol;
    @FXML
    private TableColumn<MealList, String> lunchCol;
    @FXML
    private TableColumn<MealList, String> dinnerCol;
    @FXML
    private DatePicker searchDate;
    @FXML
    private TextField selectedUser;

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        //JFXDepthManager.setDepth(lunch, 0);
        databaseHandler = new DatabaseHandler();

        loadMember();

        initCol();
        datePicker.setValue(LocalDate.now());
        DateTimeFormatter dtf = DateTimeFormatter.ofPattern("dd-MM-yyyy");
        LocalDate localDate = LocalDate.now();
        loadData(dtf.format(localDate).toString());

    }

    @FXML
    private void updateAction(ActionEvent event) throws SQLException {
        String selectedDate = "";
        String username = selectedUser.getText();
        String brekfst = breakfast.getText();
        String lnce = lunch.getText();
        String dnr = dinner.getText();

        
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd-MM-yyyy");
        LocalDate date = datePicker.getValue();
        selectedDate = formatter.format(date);
        
        String isUpdate = databaseHandler.updateMeal(selectedDate,username,brekfst,lnce,dnr);
            if (isUpdate.equals("yes")) {
                Alert alert = new Alert(Alert.AlertType.INFORMATION);
                alert.setHeaderText("");
                alert.setContentText("Successfully Updated");
                alert.showAndWait();

                mealList.clear();
                loadData(selectedDate);
            } else {
                Alert alert = new Alert(Alert.AlertType.ERROR);
                alert.setHeaderText("");
                alert.setContentText("Failed to Update");
                alert.showAndWait();
            }
    }

    @FXML
    private void saveAction(ActionEvent event) throws SQLException {
        String selectedDate = "";
        String username = memberCombo.getValue().toString();
        String brekfst = breakfast.getText();
        String lnce = lunch.getText();
        String dnr = dinner.getText();

        
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd-MM-yyyy");
        LocalDate date = datePicker.getValue();
        selectedDate = formatter.format(date);
        if (datePicker.getValue() != null) {
            //display.setText(formatter.format(date));
            selectedDate = formatter.format(date);
        } else {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setHeaderText("");
            alert.setContentText("Please Select Date");
            alert.showAndWait();
            return;
        }
        if (username.isEmpty() || brekfst.isEmpty() || lnce.isEmpty() || dnr.isEmpty()) {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setHeaderText("");
            alert.setContentText("Please Fill all the fields");
            alert.showAndWait();
            return;
        }

        String sDate = selectedDate.toString();
        String isUser = checkUserMeal(sDate);
        if(!isUser.equals("")){
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setHeaderText("");
            alert.setContentText("Already entered..please update");
            alert.showAndWait();
            return;
        }

        String qu = "INSERT INTO MEAL VALUES ("
                + "'" + selectedDate + "',"
                + "'" + username + "',"
                + "'" + brekfst + "',"
                + "'" + lnce + "',"
                + "'" + dnr + "'"
                + ")";

        if (databaseHandler.execAction(qu)) {

            Alert alert = new Alert(Alert.AlertType.INFORMATION);
            alert.setHeaderText("");
            alert.setContentText("Successfully Added");
            alert.showAndWait();
            
            mealList.clear();
            loadData(sDate);
            
            breakfast.setText("0");
            lunch.setText("0");
            dinner.setText("0");

        } else {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setHeaderText("");
            alert.setContentText("Failed To Add meal");
            alert.showAndWait();
        }
    }

    void loadMember() {
        String query = "select userName from USERS";

        ResultSet rs = databaseHandler.execQuery(query);

        try {
            while (rs.next()) {
                memberList.add(rs.getString("userName"));
            }

            memberCombo.setItems(memberList);
        } catch (SQLException ex) {
            Logger.getLogger(Add_mealController.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    public void checkUser() throws SQLException {
        String query = "select * from MEAL where date = '15-05-2018'";
        String isUser = "";
        ResultSet rs = databaseHandler.execQuery(query);
        System.out.println(query);
        while (rs.next()) {
            isUser = rs.getString("date");
            System.out.println(isUser);
        }

    }
    public String checkUserMeal(String sDate) throws SQLException {
        String query = "select userName from MEAL where userName = '"+memberCombo.getValue().toString()+"' and date = '"+sDate+"'";
        System.out.println(query);
        String isUser = "";
        ResultSet rs = databaseHandler.execQuery(query);
        System.out.println(query);
        while (rs.next()) {
            isUser = rs.getString("userName");
            
        }
        return isUser;

    }
   

    public void loadData(String sDate) {

        try {
            String sql = "";
            if (sDate.equals("")) {
                DateTimeFormatter dtf = DateTimeFormatter.ofPattern("dd-MM-yyyy");
                LocalDate localDate = LocalDate.now();

                sql = "select * from MEAL where date = '" + (dtf.format(localDate).toString()) + "'";
            } else {
                sql = "select * from MEAL where date = '" + sDate + "'";
            }

            ResultSet rs = databaseHandler.execQuery(sql);
            while (rs.next()) {
                String dte = rs.getString("date");
                String usr = rs.getString("userName");
                String brkfst = rs.getString("breakfast");
                String lnc = rs.getString("lunch");
                String dnr = rs.getString("dinner");
                
                mealList.add(new MealList(dte, usr, brkfst, lnc, dnr));
                
            }
            tableView.getItems().setAll(mealList);
            
        } catch (SQLException ex) {
            Logger.getLogger(Add_mealController.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    private void initCol() {
        dateCol.setCellValueFactory(new PropertyValueFactory<>("date"));
        userCol.setCellValueFactory(new PropertyValueFactory<>("userName"));
        bfCol.setCellValueFactory(new PropertyValueFactory<>("breakfast"));
        lunchCol.setCellValueFactory(new PropertyValueFactory<>("lunch"));
        dinnerCol.setCellValueFactory(new PropertyValueFactory<>("dinner"));
    }

    @FXML
    private void searchDateAction(MouseEvent event) throws SQLException {
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd-MM-yyyy");
        LocalDate date = searchDate.getValue();
        String selectedDate = formatter.format(date);
            
        mealList.clear();
        loadData(selectedDate);
        datePicker.setValue(date);
    }

    @FXML
    private void tableMouseClick(MouseEvent event) {
        selectedMemberList.clear();
        
        MealList tableData = tableView.getSelectionModel().getSelectedItem();
        breakfast.setText(tableData.getBreakfast());
        lunch.setText(tableData.getLunch());
        dinner.setText(tableData.getDinner());
        selectedUser.setText(tableData.getUserName());
        
        
        
    }

    public static class MealList{
        private final SimpleStringProperty date;
        private final SimpleStringProperty userName;
        private final SimpleStringProperty breakfast;
        private final SimpleStringProperty lunch;
        private final SimpleStringProperty dinner;

        public MealList(String date, String userName, String breakfast, String lunch, String dinner) {
            this.date = new SimpleStringProperty(date);
            this.userName = new SimpleStringProperty(userName);
            this.breakfast = new SimpleStringProperty(breakfast);
            this.lunch = new SimpleStringProperty(lunch);
            this.dinner = new SimpleStringProperty(dinner);
        }

        public String getDate() {
            return date.get();
        }

        public String getUserName() {
            return userName.get();
        }

        public String getBreakfast() {
            return breakfast.get();
        }

        public String getLunch() {
            return lunch.get();
        }

        public String getDinner() {
            return dinner.get();
        }
        
        
        
        
    }

}
