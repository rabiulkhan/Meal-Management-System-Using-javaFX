/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mealmanagementsystem.ui.contribution;

import java.net.URL;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.temporal.TemporalAdjusters;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.beans.property.SimpleStringProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.DatePicker;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.input.MouseEvent;
import javafx.scene.text.Text;
import mealmanagementsystem.database.DatabaseHandler;

/**
 * FXML Controller class
 *
 * @author md.rabiulkhan
 */
public class ContributionController implements Initializable {

    @FXML
    private DatePicker datePicker;
    @FXML
    private ComboBox<?> userName;
    @FXML
    private TextField given;
    @FXML
    private Button updateBtn;
    @FXML
    private Button saveBtn;
    @FXML
    private TableColumn<Contrib, String> dateCol;
    @FXML
    private TableColumn<Contrib, String> userCol;
    @FXML
    private TableColumn<Contrib, String> givenCol;
    private TableColumn<ContribTotal, String> avgDateCol;
    @FXML
    private TableColumn<ContribTotal, String> avgUserCol;
    @FXML
    private TableColumn<ContribTotal, String> avgGivenCol;
    @FXML
    private TableView<Contrib> tableView;
    @FXML
    private TableView<ContribTotal> totalTableView;
    
    DatabaseHandler databaseHandler;
    ObservableList memberList = FXCollections.observableArrayList();
    
    ObservableList<Contrib> dataList = FXCollections.observableArrayList();
    ObservableList<ContribTotal> totaldataList = FXCollections.observableArrayList();
    @FXML
    private DatePicker datePickerSearch;
    @FXML
    private Text searchBtn;
    @FXML
    private Text msgText;
    @FXML
    private Text selectedUser;

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        databaseHandler = new DatabaseHandler();

        loadMember();
        initColIndv();
        initColTotal();
        DateTimeFormatter dtf = DateTimeFormatter.ofPattern("dd-MM-yyyy");
        LocalDate localDate = LocalDate.now();
        loadInvData(localDate);
        loadTotalData(localDate);
    }    

    @FXML
    private void updateBtnAction(ActionEvent event) throws SQLException {
        String selectedDate = "";
        String username = selectedUser.getText();
        String amount = given.getText();

        
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd-MM-yyyy");
        LocalDate date = datePicker.getValue();
        selectedDate = formatter.format(date);
        
        String isUpdate = databaseHandler.updateContrib(selectedDate,username,amount);
            if (isUpdate.equals("yes")) {
                Alert alert = new Alert(Alert.AlertType.INFORMATION);
                alert.setHeaderText("");
                alert.setContentText("Successfully Updated");
                alert.showAndWait();

                dataList.clear();
                totaldataList.clear();
                loadInvData(date);
                loadTotalData(date);
            } else {
                Alert alert = new Alert(Alert.AlertType.ERROR);
                alert.setHeaderText("");
                alert.setContentText("Failed to Update");
                alert.showAndWait();
            }
    }

    @FXML
    private void saveBtnAction(ActionEvent event) {
        String selectedDate = "";
        String username = userName.getValue().toString();
        String amount = given.getText();

        
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd-MM-yyyy");
        LocalDate date = datePicker.getValue();
        selectedDate = formatter.format(date);
        String sDate = selectedDate.toString();
        if (datePicker.getValue() != null) {
            //display.setText(formatter.format(date));
            selectedDate = formatter.format(date);
        } else {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setHeaderText("");
            alert.setContentText("Please Select Date");
            alert.showAndWait();
            return;
        }
        
        String qu = "INSERT INTO CONTRIBUTION VALUES ("
                + "'" + selectedDate + "',"
                + "'" + username + "',"
                + "'" + amount + "'"
                + ")";

        if (databaseHandler.execAction(qu)) {

            Alert alert = new Alert(Alert.AlertType.INFORMATION);
            alert.setHeaderText("");
            alert.setContentText("Successfully Added");
            alert.showAndWait();
            
            dataList.clear();
            loadInvData(date);
            
            given.setText("0");

        } else {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setHeaderText("");
            alert.setContentText("Failed To Add meal");
            alert.showAndWait();
        }
    }

    @FXML
    private void mouseClickAction(MouseEvent event) {
        Contrib tableData = tableView.getSelectionModel().getSelectedItem();
        given.setText(tableData.getGiven());
        selectedUser.setText(tableData.getUserName());
        
    }
    
    
    
    void loadMember() {
        try {
            String query = "select userName from USERS";
            
            ResultSet rs = databaseHandler.execQuery(query);
            
            
            while (rs.next()) {
                memberList.add(rs.getString("userName"));
            }

            userName.setItems(memberList);
        } catch (SQLException ex) {
            Logger.getLogger(ContributionController.class.getName()).log(Level.SEVERE, null, ex);
        }
        
    }
    
    void loadInvData(LocalDate today){
        try {
            DateTimeFormatter dtf = DateTimeFormatter.ofPattern("dd-MM-yyyy");
            LocalDate first = today.withDayOfMonth(1);
            String firstDay = dtf.format(first).toString();
            LocalDate last = today.withDayOfMonth(today.lengthOfMonth());
            String lastDay = dtf.format(last).toString();
            
            String sql = "select * from CONTRIBUTION where date >= '"+firstDay+"' and date <= '"+lastDay+"'";
            //String sql = "select userName,Sum(cast(amount as DECIMAL(9,2))) as amount from CONTRIBUTION  group by userName order by userName";
            
            ResultSet rs = databaseHandler.execQuery(sql);
            while (rs.next()) {
                String dte = rs.getString("date");
                String usr = rs.getString("userName");
                String amount = rs.getString("amount");
                dataList.add(new Contrib(dte, usr, amount));
                
            }
            tableView.getItems().setAll(dataList);
            
        } catch (SQLException ex) {
            Logger.getLogger(ContributionController.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    void loadTotalData(LocalDate today){
        try {
            DateTimeFormatter dtf = DateTimeFormatter.ofPattern("dd-MM-yyyy");
            LocalDate first = today.withDayOfMonth(1);
            String firstDay = dtf.format(first).toString();
            LocalDate last = today.withDayOfMonth(today.lengthOfMonth());
            String lastDay = dtf.format(last).toString();
            
            msgText.setText("Total Contribution between "+firstDay+" to "+lastDay);
            
            //String sql = "select * from CONTRIBUTION where date >= '"+firstDay+"' and date <= '"+lastDay+"'";
            String sql = "select userName,Sum(cast(amount as DECIMAL(9,2))) as amount from CONTRIBUTION  group by userName order by userName";
            
            ResultSet rs = databaseHandler.execQuery(sql);
            while (rs.next()) {
                String usr = rs.getString("userName");
                String amount = rs.getString("amount");
                totaldataList.add(new ContribTotal(usr, amount));
                
            }
            totalTableView.getItems().setAll(totaldataList);
            
        } catch (SQLException ex) {
            Logger.getLogger(ContributionController.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    void initColIndv(){
        dateCol.setCellValueFactory(new PropertyValueFactory<>("date"));
        userCol.setCellValueFactory(new PropertyValueFactory<>("userName"));
        givenCol.setCellValueFactory(new PropertyValueFactory<>("given"));
    }
    void initColTotal(){
        avgUserCol.setCellValueFactory(new PropertyValueFactory<>("userName"));
        avgGivenCol.setCellValueFactory(new PropertyValueFactory<>("given"));
    }

    @FXML
    private void searchBtnAction(MouseEvent event) {
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd-MM-yyyy");
        LocalDate date = datePickerSearch.getValue();
        String selectedDate = formatter.format(date);
            
        dataList.clear();
        totaldataList.clear();
        loadInvData(date);
        loadTotalData(date);
        datePicker.setValue(date);
    }
    
    public static class Contrib{
        private final SimpleStringProperty date;
        private final SimpleStringProperty userName;
        private final SimpleStringProperty given;
        
        Contrib(String date, String userName, String given){
            this.date = new SimpleStringProperty(date);
            this.userName = new SimpleStringProperty(userName);
            this.given = new SimpleStringProperty(given);
        }

        public String getDate() {
            return date.get();
        }

        public String getUserName() {
            return userName.get();
        }

        public String getGiven() {
            return given.get();
        }
        
        
    }
    public static class ContribTotal{
        private final SimpleStringProperty userName;
        private final SimpleStringProperty given;
        
        ContribTotal(String userName, String given){
            this.userName = new SimpleStringProperty(userName);
            this.given = new SimpleStringProperty(given);
        }


        public String getUserName() {
            return userName.get();
        }

        public String getGiven() {
            return given.get();
        }
        
        
    }
    
}
