/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mealmanagementsystem.ui.bazar;

import java.net.URL;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.beans.property.SimpleStringProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.DatePicker;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.VBox;
import mealmanagementsystem.database.DatabaseHandler;

/**
 * FXML Controller class
 *
 * @author md.rabiulkhan
 */
public class Add_bazarController implements Initializable {

    @FXML
    private DatePicker datePicker;
    @FXML
    private ComboBox<?> userName;
    @FXML
    private TextField selectedUser;
    @FXML
    private TextField cost;
    @FXML
    private Button updateBtn;
    @FXML
    private Button saveBtn;
    @FXML
    private DatePicker selectedDatePicker;
    @FXML
    private Label loadTable;
    @FXML
    private TableView<Bazar> tableView;
    
    DatabaseHandler databaseHandler;
    ObservableList memberList = FXCollections.observableArrayList();
    @FXML
    private VBox rootPane;
    @FXML
    private TableColumn<Bazar,String> dateCol;
    @FXML
    private TableColumn<Bazar,String> userCol;
    @FXML
    private TableColumn<Bazar,String> costCol;
    
    
    ObservableList<Bazar> bazarlList = FXCollections.observableArrayList();

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        
        databaseHandler = new DatabaseHandler();

        loadMember();
        
        initCOl();
        
        datePicker.setValue(LocalDate.now());
        DateTimeFormatter dtf = DateTimeFormatter.ofPattern("dd-MM-yyyy");
        LocalDate localDate = LocalDate.now();
        loadData(dtf.format(localDate).toString());
    }    

    @FXML
    private void UpdateBtnAction(ActionEvent event) throws SQLException {
        String selectedDate = "";
        String username = selectedUser.getText();
        String bazar = cost.getText();

        
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd-MM-yyyy");
        LocalDate date = datePicker.getValue();
        selectedDate = formatter.format(date);
        
        String isUpdate = databaseHandler.updateBazar(selectedDate,username,bazar);
            if (isUpdate.equals("yes")) {
                Alert alert = new Alert(Alert.AlertType.INFORMATION);
                alert.setHeaderText("");
                alert.setContentText("Successfully Updated");
                alert.showAndWait();

                bazarlList.clear();
                loadData(selectedDate);
            } else {
                Alert alert = new Alert(Alert.AlertType.ERROR);
                alert.setHeaderText("");
                alert.setContentText("Failed to Update");
                alert.showAndWait();
            }
    }

    @FXML
    private void saveBtnAction(ActionEvent event) {
        String selectedDate = "";
        String username = userName.getValue().toString();
        if(username == ""){
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setHeaderText("");
            alert.setContentText("Please Select userName");
            alert.showAndWait();
            return;
        }
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd-MM-yyyy");
        LocalDate date = datePicker.getValue();
        selectedDate = formatter.format(date);
        String sDate = selectedDate.toString();
        if (datePicker.getValue() != null) {
            //display.setText(formatter.format(date));
            selectedDate = formatter.format(date);
        } else {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setHeaderText("");
            alert.setContentText("Please Select Date");
            alert.showAndWait();
            return;
        }
        String bazar = cost.getText();
        
        String qu = "INSERT INTO BAZAR VALUES ("
                + "'" + selectedDate + "',"
                + "'" + username + "',"
                + "'" + bazar + "'"
                + ")";

        if (databaseHandler.execAction(qu)) {

            Alert alert = new Alert(Alert.AlertType.INFORMATION);
            alert.setHeaderText("");
            alert.setContentText("Successfully Added");
            alert.showAndWait();
            
            //mealList.clear();
            bazarlList.clear();
            loadData(sDate);
            
            
            cost.setText("0");

        } else {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setHeaderText("");
            alert.setContentText("Failed To Add meal");
            alert.showAndWait();
        }
    }

    @FXML
    private void loadTableAction(MouseEvent event) {
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd-MM-yyyy");
        LocalDate date = selectedDatePicker.getValue();
        String selectedDate = formatter.format(date);
            
        bazarlList.clear();
        loadData(selectedDate);
        datePicker.setValue(date);
    }
    
    
    void loadMember() {
        try {
            String query = "select userName from USERS";
            
            ResultSet rs = databaseHandler.execQuery(query);
            
            
            while (rs.next()) {
                memberList.add(rs.getString("userName"));
            }

            userName.setItems(memberList);
        } catch (SQLException ex) {
            Logger.getLogger(Add_bazarController.class.getName()).log(Level.SEVERE, null, ex);
        }
        
    }
    
    void initCOl(){
        dateCol.setCellValueFactory(new PropertyValueFactory<>("date"));
        userCol.setCellValueFactory(new PropertyValueFactory<>("username"));
        costCol.setCellValueFactory(new PropertyValueFactory<>("cost"));
    }
    
    public void loadData(String sDate) {

       
        try {
            String sql = "";
            if (sDate.equals("")) {
                DateTimeFormatter dtf = DateTimeFormatter.ofPattern("dd-MM-yyyy");
                LocalDate localDate = LocalDate.now();

                sql = "select * from BAZAR where date = '" + (dtf.format(localDate).toString()) + "'";
            } else {
                sql = "select * from BAZAR where date = '" + sDate + "'";
            }

            ResultSet rs = databaseHandler.execQuery(sql);
            while (rs.next()) {
                String dte = rs.getString("date");
                String usr = rs.getString("userName");
                String cost = rs.getString("cost");
                
                bazarlList.add(new Bazar(dte, usr, cost));
                
            }
            tableView.getItems().setAll(bazarlList);
        } catch (SQLException ex) {
            Logger.getLogger(Add_bazarController.class.getName()).log(Level.SEVERE, null, ex);
        }
            
        
    }

    @FXML
    private void tableMouseClick(MouseEvent event) {
        //selectedMemberList.clear();
        
        Bazar tableData = tableView.getSelectionModel().getSelectedItem();
        cost.setText(tableData.getCost());
        selectedUser.setText(tableData.getUsername());
    }
    
    public static class Bazar{
        private final SimpleStringProperty date;
        private final SimpleStringProperty username;
        private final SimpleStringProperty cost;
        
        Bazar(String date, String username,String cost){
            this.date = new SimpleStringProperty(date);
            this.username = new SimpleStringProperty(username);
            this.cost = new SimpleStringProperty(cost);
        }

        public String getDate() {
            return date.get();
        }

        public String getUsername() {
            return username.get();
        }

        public String getCost() {
            return cost.get();
        }
        
        
    }
    
}
