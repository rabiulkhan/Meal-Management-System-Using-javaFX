/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mealmanagementsystem.ui.forgot_password;

import com.jfoenix.effects.JFXDepthManager;
import java.net.URL;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.VBox;
import mealmanagementsystem.database.DatabaseHandler;

/**
 * FXML Controller class
 *
 * @author md.rabiulkhan
 */
public class Forgot_passwordController implements Initializable {

    @FXML
    private AnchorPane rootPane;
    @FXML
    private TextField email;
    @FXML
    private Button showBtn;
    @FXML
    private TextField userName;
    @FXML
    private TextField Password;

    DatabaseHandler databaseHandler;
    @FXML
    private VBox userPane;
    @FXML
    private Button updateBtn;

    String user = "";

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        JFXDepthManager.setDepth(userPane, 2);

        databaseHandler = new DatabaseHandler();
    }

    @FXML
    private void showAction(ActionEvent event) {
        try {
            String uemail = email.getText();

            String query = "select * from USERS where email = '" + uemail + "'";
            String username = "", pass = "";
            ResultSet rs = databaseHandler.execQuery(query);

            while (rs.next()) {
                username = rs.getString("userName");
                pass = rs.getString("password");
            }
            if (username.isEmpty() || pass.isEmpty()) {
                Alert alert = new Alert(Alert.AlertType.ERROR);
                alert.setHeaderText("");
                alert.setContentText("Please Enter correct email");
                alert.showAndWait();
            } else {
                userName.setText(username);
                Password.setText(pass);
            }

            user = username;

        } catch (SQLException ex) {
            Logger.getLogger(Forgot_passwordController.class.getName()).log(Level.SEVERE, null, ex);
        }

    }

    @FXML
    private void updateAction(ActionEvent event) {
        String username = userName.getText();
        String pass = Password.getText();

        if (username.isEmpty() || pass.isEmpty()) {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setHeaderText("");
            alert.setContentText("Please fill in all the fields");
            alert.showAndWait();
            return;
        }
        
        String isUser = checkUser(username);
        
        if(isUser.equals("1")){
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setHeaderText("");
            alert.setContentText("User Already Exists");
            alert.showAndWait();
            return;
        }

        try {
            String isUpdate = databaseHandler.updateUser(username, pass, user);
            if (isUpdate.equals("yes")) {
                Alert alert = new Alert(Alert.AlertType.INFORMATION);
                alert.setHeaderText("");
                alert.setContentText("Successfully Updated");
                alert.showAndWait();

                userName.setText("");
                Password.setText("");
            } else {
                Alert alert = new Alert(Alert.AlertType.ERROR);
                alert.setHeaderText("");
                alert.setContentText("Failed to Update");
                alert.showAndWait();
            }
        } catch (SQLException ex) {
            Logger.getLogger(Forgot_passwordController.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    public String checkUser(String user){
        String isUser = "";
        try {
            String query = "select count(userName) as userName from USERS where userName = '"+user+"'";
            
            ResultSet rs = databaseHandler.execQuery(query);
            
            while(rs.next()){
                isUser = rs.getString("userName");
                System.out.println(isUser);
            }
            
        } catch (SQLException ex) {
            Logger.getLogger(Forgot_passwordController.class.getName()).log(Level.SEVERE, null, ex);
        }
        return isUser;
    }

}
