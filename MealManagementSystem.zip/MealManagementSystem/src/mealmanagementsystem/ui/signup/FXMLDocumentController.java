/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mealmanagementsystem.ui.signup;

import com.jfoenix.effects.JFXDepthManager;
import java.net.URL;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;
import mealmanagementsystem.database.DatabaseHandler;

/**
 *
 * @author md.rabiulkhan
 */
public class FXMLDocumentController implements Initializable {
    
    private Label label;
    @FXML
    private VBox signupPane;
    @FXML
    private TextField fullName;
    @FXML
    private TextField userName;
    @FXML
    private TextField email;
    @FXML
    private PasswordField password;
    @FXML
    private Button cancelBtn;
    @FXML
    private Button signupBtn;
    
    DatabaseHandler databaseHandler;
    
    private void handleButtonAction(ActionEvent event) {
        System.out.println("You clicked me!");
        label.setText("Hello World!");
    }
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        JFXDepthManager.setDepth(signupPane, 2);
        databaseHandler = new DatabaseHandler();
        
        
    }    

    @FXML
    private void cancelAction(ActionEvent event) {
        Stage stage = (Stage) signupPane.getScene().getWindow();
        stage.close();
    }

    @FXML
    private void signUpAction(ActionEvent event) {
        String fullname = fullName.getText();
        String username = userName.getText();
        String uemail = email.getText();
        String pass = password.getText();
        String isUser = checkUser(username);
        String isEmail = checkEmail(uemail);
        
        if(isUser.equals("1")){
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setHeaderText("");
            alert.setContentText("User Already Exists");
            alert.showAndWait();
            return;
        }
        if(isEmail.equals("1")){
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setHeaderText("");
            alert.setContentText("Email Already Exists");
            alert.showAndWait();
            return;
        }
        
        if(!uemail.contains("@")){
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setHeaderText("");
            alert.setContentText("Please Enter correct email format");
            alert.showAndWait();
            return;
        }
        
        if(fullname.isEmpty() || username.isEmpty() || uemail.isEmpty() || pass.isEmpty()){
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setHeaderText("");
            alert.setContentText("Please Enter in all fields");
            alert.showAndWait();
            return;
        }
        String qu = "INSERT INTO USERS VALUES ("+
                "'"+ fullname +"',"+
                "'"+ username +"',"+
                "'"+ uemail +"',"+
                "'"+ pass +"'"+
                ")";
        
        if(databaseHandler.execAction(qu)){
            Alert alert = new Alert(Alert.AlertType.INFORMATION);
            alert.setHeaderText("");
            alert.setContentText("Successfully Registered");
            alert.showAndWait();
            
            fullName.setText("");
            userName.setText("");
            email.setText("");
            password.setText("");
        }else{
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setHeaderText("");
            alert.setContentText("Failed To Registration");
            alert.showAndWait();
        }
    }
    
    public String checkUser(String user){
        String query = "select count(userName) as userName from USERS where userName = '"+user+"'";
        String isUser = "";
        ResultSet rs = databaseHandler.execQuery(query);
        try {
            while(rs.next()){
                isUser = rs.getString("userName");
                System.out.println(isUser);
            }
        } catch (SQLException ex) {
            Logger.getLogger(FXMLDocumentController.class.getName()).log(Level.SEVERE, null, ex);
        }
        return isUser;
    }
    public String checkEmail(String email){
        String query = "select count(userName) as userName from USERS where email = '"+email+"'";
        String isUser = "";
        ResultSet rs = databaseHandler.execQuery(query);
        try {
            while(rs.next()){
                isUser = rs.getString("userName");
                System.out.println(isUser);
            }
        } catch (SQLException ex) {
            Logger.getLogger(FXMLDocumentController.class.getName()).log(Level.SEVERE, null, ex);
        }
        return isUser;
    }
    
    
    
}
