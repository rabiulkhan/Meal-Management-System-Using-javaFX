
package mealmanagementsystem.database;

import java.sql.Connection;
import java.sql.DatabaseMetaData;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.scene.control.Alert;
import javax.swing.JOptionPane;
import mealmanagementsystem.ui.forgot_password.Forgot_passwordController;

/**
 *
 * @author md.rabiulkhan
 */
public class DatabaseHandler {
    private static DatabaseHandler handler = null;

    private static final String DB_URL = "jdbc:derby:database;create=true";
    private static Connection conn = null;
    private static Statement stmt = null;
    
    public DatabaseHandler(){
        createConnection();
        setupUserTable();
        setupMealTable();
        setupBazarTable();
        setupContributionTable();
    }
    
    void createConnection() {
        try {
            Class.forName("org.apache.derby.jdbc.EmbeddedDriver").newInstance();
            conn = DriverManager.getConnection(DB_URL);
            
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Cant load database", "Database Error", JOptionPane.ERROR_MESSAGE);
            System.exit(0);
        }
    }
    
    void setupUserTable(){
        String TABLE_NAME = "USERS";
        
        try{
            stmt = conn.createStatement();
            DatabaseMetaData dbm = conn.getMetaData();
            ResultSet tables = dbm.getTables(null, null, TABLE_NAME.toUpperCase(), null);
            if(tables.next()){
                System.out.println("Table "+TABLE_NAME +" already Exists");
            }
            else{
                stmt.execute("CREATE TABLE "+TABLE_NAME+"("
                        + "fullName varchar(200),\n"
                        + "userName varchar(200),\n"
                        + "email varchar(200),\n"
                        + "password varchar(200)"
                        + ")");
            }
        }catch(SQLException ex){
            System.err.println(ex.getMessage() +" ... setup users table");
        }
    }
    void setupMealTable(){
        String TABLE_NAME = "MEAL";
        
        try{
            stmt = conn.createStatement();
            DatabaseMetaData dbm = conn.getMetaData();
            ResultSet tables = dbm.getTables(null, null, TABLE_NAME.toUpperCase(), null);
            if(tables.next()){
                System.out.println("Table "+TABLE_NAME +" already Exists");
            }
            else{
                stmt.execute("CREATE TABLE "+TABLE_NAME+"("
                        + "date varchar(200),\n"
                        + "userName varchar(200),\n"
                        + "breakfast varchar(20),\n"
                        + "lunch varchar(20),\n"
                        + "dinner varchar(20)"
                        + ")");
            }
        }catch(SQLException ex){
            System.err.println(ex.getMessage() +" ... setup users table");
        }
    }
    void setupBazarTable(){
        String TABLE_NAME = "BAZAR";
        
        try{
            stmt = conn.createStatement();
            DatabaseMetaData dbm = conn.getMetaData();
            ResultSet tables = dbm.getTables(null, null, TABLE_NAME.toUpperCase(), null);
            if(tables.next()){
                System.out.println("Table "+TABLE_NAME +" already Exists");
            }
            else{
                stmt.execute("CREATE TABLE "+TABLE_NAME+"("
                        + "date varchar(200),\n"
                        + "userName varchar(200),\n"
                        + "cost varchar(20)"
                        + ")");
            }
        }catch(SQLException ex){
            System.err.println(ex.getMessage() +" ... setup users table");
        }
    }
    
    void setupContributionTable(){
        String TABLE_NAME = "CONTRIBUTION";
        
        try{
            stmt = conn.createStatement();
            DatabaseMetaData dbm = conn.getMetaData();
            ResultSet tables = dbm.getTables(null, null, TABLE_NAME.toUpperCase(), null);
            if(tables.next()){
                System.out.println("Table "+TABLE_NAME +" already Exists");
            }
            else{
                stmt.execute("CREATE TABLE "+TABLE_NAME+"("
                        + "date varchar(200),\n"
                        + "userName varchar(200),\n"
                        + "amount varchar(20)"
                        + ")");
            }
        }catch(SQLException ex){
            System.err.println(ex.getMessage() +" ... setup users table");
        }
    }
    
     public ResultSet execQuery(String query) {
        ResultSet result;
        try {
            stmt = conn.createStatement();
            result = stmt.executeQuery(query);
        } catch (SQLException ex) {
            System.out.println("Exception at execQuery:dataHandler" + ex.getLocalizedMessage());
            return null;
        } finally {
        }
        return result;
    }

    public boolean execAction(String qu) {
        try {
            stmt = conn.createStatement();
            stmt.execute(qu);
            return true;
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Error:" + ex.getMessage(), "Error Occured", JOptionPane.ERROR_MESSAGE);
            System.out.println("Exception at execQuery:dataHandler" + ex.getLocalizedMessage());
            return false;
        } finally {
        }
    }
    
    public String updateUser(String username, String pass,String user) throws SQLException{
        String sql = "UPDATE USERS set userName = '"+username+"',password = '"+pass+"' where userName = '"+user+"'";
        Statement st = conn.createStatement();
        
        String isUpdate = "";
        
        try {
            st.executeUpdate(sql);
            isUpdate = "yes";
            
        } catch (SQLException ex) {
            
            isUpdate = "no";
            Logger.getLogger(Forgot_passwordController.class.getName()).log(Level.SEVERE, null, ex);
        }
        return isUpdate;
    }
    
    public String updateMeal(String sDate, String user, String bf, String lunce, String dnr) throws SQLException{
        String sql = "UPDATE MEAL set date='"+sDate+"',breakfast='"+bf+"',lunch='"+lunce+"',dinner='"+dnr+"' where userName = '"+user+"' and date='"+sDate+"'";
        Statement st = conn.createStatement();
        
        String isUpdate = "";
        
        try {
            st.executeUpdate(sql);
            isUpdate = "yes";
            
        } catch (SQLException ex) {
            
            isUpdate = "no";
            Logger.getLogger(Forgot_passwordController.class.getName()).log(Level.SEVERE, null, ex);
        }
        return isUpdate;
    }
    public String updateBazar(String sDate, String user, String cost) throws SQLException{
        String sql = "UPDATE BAZAR set date='"+sDate+"',userName='"+user+"',cost='"+cost+"' where userName = '"+user+"' and date='"+sDate+"'";
        Statement st = conn.createStatement();
        
        String isUpdate = "";
        
        try {
            st.executeUpdate(sql);
            isUpdate = "yes";
            
        } catch (SQLException ex) {
            
            isUpdate = "no";
            Logger.getLogger(Forgot_passwordController.class.getName()).log(Level.SEVERE, null, ex);
        }
        return isUpdate;
    }
    public String updateContrib(String sDate, String user, String amount) throws SQLException{
        String sql = "UPDATE CONTRIBUTION set date='"+sDate+"',userName='"+user+"',amount='"+amount+"' where userName = '"+user+"' and date='"+sDate+"'";
        Statement st = conn.createStatement();
        
        String isUpdate = "";
        
        try {
            st.executeUpdate(sql);
            isUpdate = "yes";
            
        } catch (SQLException ex) {
            
            isUpdate = "no";
            Logger.getLogger(Forgot_passwordController.class.getName()).log(Level.SEVERE, null, ex);
        }
        return isUpdate;
    }
    
    public String delete(String sql1,String sql2,String sql3,String sql4){
        String msg = "";
        try {
            Statement st1 = conn.createStatement();
            st1.executeUpdate(sql1);
            st1.close();
            Statement st2 = conn.createStatement();
            st2.executeUpdate(sql2);
            st2.close();
            Statement st3 = conn.createStatement();
            st3.executeUpdate(sql3);
            st3.close();
            Statement st4 = conn.createStatement();
            st4.executeUpdate(sql4);
            st4.close();
            
            msg = "yes";
        } catch (SQLException ex) {
            msg = "no";
            Logger.getLogger(DatabaseHandler.class.getName()).log(Level.SEVERE, null, ex);
        }
        return msg;
    }
}
